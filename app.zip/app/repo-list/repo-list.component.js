'use strict';

// Register `RepoList` component, along with its associated controller and template
angular.module('repoList').
  component('repoList', {
    templateUrl: 'repo-list/repo-list.template.html',
    controller: ['$routeParams','Repo','$scope',
      function RepoListController($routeParams,Repo,$scope) {
              
         // this.userName = $routeParams.username;
          $scope.userDetails = {};

          $scope.loaded = true ;
          $scope.userNotFound = false;
          $scope.loaded = false;
          $scope.loader = true;
         // $scope.startLoader();
         Repo.gitHubRepoDetails($routeParams.username)
          .then(function ( response ) {
            Repo.setUserRepo(response.data);
              $scope.repos = Repo.getUserRepo();
              $scope.loaded = false;
              $scope.userDetails  = Repo.getUserDetails();
             // this.Repos =  response.data;

             if(!$scope.uesrDetails){
              $scope.loaded = false;
             // $scope.startLoader(); 
              Repo.gitHubUserDetails($routeParams.username)
                .then(function ( response ) {
                   if ( response.data.name == "" ) {
                     $scope.userNotFound = true;
                   }else{
                    Repo.setUserDetails(response.data);
                    //$scope.userDetails = response.data;
                    $scope.loaded = true;
                    $scope.loader =false;
                    $scope.userDetails  = Repo.getUserDetails();
                   // $scope.stopLoader();
                   }
                }, function () {
                  $scope.loader = false;
                  $scope.userNotFound = true;
                 
                  return;
                });
            }
             
             
          }, function () {
              $scope.loader = false;
             $scope.userNotFound = true;
            
          });
      
        } 
    ]
  });
