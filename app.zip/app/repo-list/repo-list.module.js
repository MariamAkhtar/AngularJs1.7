'use strict';

// Define the `repoList` module
angular.module('repoList', []);

