'use strict';

// Define the `core` module
angular.module('core', ['core.repo','core.utility']);
