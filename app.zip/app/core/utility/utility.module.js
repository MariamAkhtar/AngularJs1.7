'use strict';

// Define the `core.repo` module
angular.module('core.utility', []);
