// directive for loader while on request
angular.
  module('core')
.directive('loaderSpin', function () {
    return{
        restrict: 'EA',
        scope: {
            loader: '='
          },
        template: '<div id="spinner-wrapper" ng-show="loader"><div id="spinner-mask"></div><span class="spinner"></span></div>'
    }
});

    
//directive for header and footer  
angular.
  module('core').directive('headerTpl', function () {
    return{
      restrict: 'E',
      scope: false,
      templateUrl: 'core/utility/header.template.html',
      controller: $.noop
    };
  });
  
  angular.
  module('core').directive('footerTpl', function () {
    return{
      restrict: 'E',
      scope: false,
      template: '<footer><div class="container"><p>Footer details can be placed here.</p></div></footer>',
      controller: $.noop
    };
  });
  