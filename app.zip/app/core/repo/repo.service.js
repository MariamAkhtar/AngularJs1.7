
'use strict';
 angular.module('core.repo').

factory('Repo',['$http','$resource', function($http,$resource) {
    var Repo = {};

    // call to server to get/post/update/delete data
    Repo.AGServer = {
        get: function(url){
            url = this.createUrl(url);
            return $http.get(url);
        },
        post: function (url, data) {
            url = this.createUrl(url);
            return $http.post(url, data);
        },
        put: function (url, data) {
            url = this.createUrl(url);
            return $http.put(url, data);
        },
        delete: function (url) {
            url = this.createUrl(url);
            return $http.delete(url);
        },
        createUrl: function(url){
            if(url.indexOf("?") == -1){
                url = url + "?";
            } else if(url[url.length -1] != "?"){
                url = url + "&";
            }
            return (url + repo.token);
        }
    };
    
    
    Repo.getUserRepo = function () {
      return this.userRepo;
    }
    
    Repo.setUserRepo = function ( userRepo ) {
      this.userRepo = userRepo;
    }
    
    Repo.getUserDetails = function () {
      return this.userDetails;
    }
    
    Repo.setUserDetails = function ( userDetails ) {
      this.userDetails = userDetails;
    }
    
    Repo.gitHubRepoDetails = function( userName ) {
      var url = "//api.github.com/users/" + userName + "/repos" ;
      return $http.get(url);
    }
    
    Repo.gitHubUserDetails = function(  userName, $scope, service ) {
      var url = "//api.github.com/users/" + userName ;
      return $http.get(url);
    }
    
    Repo.gitHubRepoReadMeFileDetails = function ( userName, repoName ) {
      var url = "//api.github.com/repos/" + userName + "/" + repoName + "/readme";
      return $http.get(url);
    }
    
    return Repo;
}]);

