'use strict';

describe('Repo', function() {
  var $httpBackend;
  var Repo;
  var repoData =[{"login": "Mariam",
    "id": 131976,
    "node_id": "MDQ6VXNlcjEzMTk3Ng==",
    "avatar_url": "https://avatars1.githubusercontent.com/u/131976?v=4",
    "gravatar_id": "",
    "url": "https://api.github.com/users/Mariam",
    "html_url": "https://github.com/Mariam",
    "followers_url": "https://api.github.com/users/Mariam/followers",
    "following_url": "https://api.github.com/users/Mariam/following{/other_user}",
    "gists_url": "https://api.github.com/users/Mariam/gists{/gist_id}",
    "starred_url": "https://api.github.com/users/Mariam/starred{/owner}{/repo}",
    "subscriptions_url": "https://api.github.com/users/Mariam/subscriptions",
    "organizations_url": "https://api.github.com/users/Mariam/orgs",
    "repos_url": "https://api.github.com/users/Mariam/repos",
    "events_url": "https://api.github.com/users/Mariam/events{/privacy}",
    "received_events_url": "https://api.github.com/users/Mariam/received_events",
    "type": "User",
    "site_admin": false,
    "name": null,
    "company": null,
    "blog": "",
    "location": null,
    "email": null,
    "hireable": null,
    "bio": null,
    "public_repos": 0,
    "public_gists": 0,
    "followers": 3,
    "following": 1,
    "created_at": "2009-09-27T21:17:34Z",
    "updated_at": "2012-11-23T21:43:17Z"}];

  // Add a custom equality tester before each test
  beforeEach(function() {
    jasmine.addCustomEqualityTester(angular.equals);
  });

  // Load the module that contains the `Repo` service before each test
  beforeEach(module('core.repo'));

  // Instantiate the service and "train" `$httpBackend` before each test
  beforeEach(inject(function(_$httpBackend_, _Repo_) {
    $httpBackend = _$httpBackend_;
    var url = "//api.github.com/users/mariam/repos" ;
    $httpBackend.expectGET('url').respond(repoData);

    Repo = _Repo_;
  }));

  // Verify that there are no outstanding expectations or requests after each test
  afterEach(function () {
    $httpBackend.verifyNoOutstandingExpectation();
    $httpBackend.verifyNoOutstandingRequest();
  });

  it('should fetch the repo data from `//api.github.com/users/mariam/repos`', function() {
    var repos = Repo.query();

    expect(phones).toEqual([]);

    $httpBackend.flush();
    expect(phones).toEqual(phonesData);
  });

});
