'use strict';

// Define the `githubSearchApp` module
angular.module('githubSearchApp', [
  'core',
  'homePage',
  'ngRoute',
  'repoDetail',
  'repoList',
  'ngSanitize',
  'btford.markdown',
]);
