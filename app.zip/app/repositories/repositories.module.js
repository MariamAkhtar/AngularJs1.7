// Define the `repositories ` module
angular.module('repositories', [
  'ngRoute'
]);