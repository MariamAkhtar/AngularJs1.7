angular.
  module('repositories').
  component('repositories', {  // This name is what AngularJS uses to match to the `<phone-list>` element.
  templateUrl: 'repositories/repositories.template.html',
       
    controller: function repositoriesController() {
      this.phones = [
        {
          name: 'Nexus Sfdasgdagdasgdas',
          snippet: 'Fast just got faster with Nexus S.'
        }, {
          name: 'Motorola XOOM™ with Wi-Fi',
          snippet: 'The Next, Next Generation tablet.'
        }, {
          name: 'MOTOROLA XOOM™',
          snippet: 'The Next, Next Generation tablet.'
        }
      ];
    }
  });