'use strict';

// Register `repoDetail` component, along with its associated controller and template
angular.
  module('repoDetail').
  component('repoDetail', {
    templateUrl: 'repo-detail/repo-detail.template.html',
    controller: ['$scope', '$http','$routeParams', 'Repo',
      function RepoDetailController($scope, $http,$routeParams, Repo) {
        $scope.loader = true ;
        Repo.gitHubRepoReadMeFileDetails($routeParams.username , $routeParams.reponame )
      .then(function (data) { 
        $scope.loader = true;
        $http.get(data.data.download_url).then(function (data) {
         $scope.readme = data.data;
         $scope.loader = false ;
        
        });
    }, function () {
      $scope.loader = false ;
    });
      }
    ]
  });
