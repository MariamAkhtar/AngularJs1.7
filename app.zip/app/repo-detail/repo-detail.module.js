'use strict';

// Define the `repoDetail` module
angular.module('repoDetail', [
  'ngRoute',
  'core.repo'
]);
