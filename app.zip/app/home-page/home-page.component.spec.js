'use strict';



describe('homePage', function() {

  // Define this test's local variables
  var scope,
      $location,
      MainCtrl;

  // Load the controller's module
  beforeEach(module('homePage'));

  beforeEach(inject(function(controller, $rootScope, _$location_) {

    scope = $rootScope.$new();
    $location = _$location_;
    spyOn($location, 'path');
    MainCtrl = $controller('HomePageController', {
      $scope: scope,
      API: {token: false},
      $location: $location
    });

  }));

  it('should exist', function() {
    expect(MainCtrl).toBeTruthy();
  });

  describe('when created', function() {

    it('should call $location accordingly', function () {
      expect($location.path).toHaveBeenCalledWith('/');
    });

  });

});









