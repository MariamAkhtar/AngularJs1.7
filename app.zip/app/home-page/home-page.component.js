'use strict';

// Register `homePage` component, along with its associated controller and template
angular.
  module('homePage').
  component('homePage', {
    templateUrl: 'home-page/home-page.template.html',
    controller: ['$scope','$location',
      function HomePageController($scope, $location) {
          $scope.loader = false;
          $scope.getGitInfo = function () {
            $scope.loader = true;
              if($scope.user) {
                
          $location.path('/repositories/' + $scope.user.userName); 
              } else {
                console.log("no data found");
              }
       
       };

      }
    ]
  });
