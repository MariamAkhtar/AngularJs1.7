'use strict';

// Define the `homePage` module
angular.module('homePage', ['core.repo']);
